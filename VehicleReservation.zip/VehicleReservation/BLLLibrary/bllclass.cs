﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DALLibrary;
using System.Data;

namespace BLLLibrary
{
    public class bllclass
    {
        dalclass dc = new dalclass();

        public void Insert_AdminBL(string _employeeidad, string _fnamead, string _lnamead, int _agead, string _genderad, string _contactnoad, string _emailad, string _passwordad, string _securityqnad, string _securityansad, string _branchad)
        {
            dc.Admin_Info(_employeeidad, _fnamead, _lnamead, _agead, _genderad, _contactnoad, _emailad, _passwordad, _securityqnad, _securityansad, _branchad);
        }


        public void Insert_UserBL(string _employeeid, string _fname, string _lname, int _age, string _gender, string _contactno, string _email, string _password,string _securityqn,string _securityans, string _branch)
        {
             dc.User_Info(_employeeid,_fname,_lname,_age,_gender,_contactno,_email,_password,_securityqn,_securityans,_branch);
        }

        public int LoginBAL(string _employeeid, string _password)
        {
            int a=dc.LoginDAL(_employeeid,_password);
            return a;
        }

        public int LoginadBAL(string _employeeidad, string _passwordad)
        {
            int a = dc.LoginadDAL(_employeeidad, _passwordad);
            return a;
        }

        public int SecurityBAL(string _employeeid, string _securityqn, string _securityans)
        {
            int a = dc.SecurityDAL(_employeeid, _securityqn, _securityans);
            return a;
        }
        public int SecurityadBAL(string _employeeidad,string _securityqnad,string _securityansad)
        {
            int a = dc.SecurityadDAL(_employeeidad,_securityqnad,_securityansad);
            return a;
        }

        public void ForgotBAL(string _employeeid, string _password)
        {
            dc.ForgotDAL(_employeeid,_password);
        }

        public void ForgotadBAL(string _employeeidad, string _passwordad)
        {
            dc.ForgotadDAL(_employeeidad, _passwordad);
        }


        public DataTable  SearchBL(string vehicle_no)
        {
            DataTable d = dc.Search(vehicle_no);
            return d;

        }
        public string ExpiryDate(string vehicle_no)
        {
            string message = "";
            DateTime Exp = dc.InsuranceExpiry(vehicle_no);
            //DateTime Exp = DateTime.Parse(a);
            DateTime now = DateTime.Now;
            TimeSpan diff = Exp - now;
            int end = diff.Days;
            
            if (end <= 15)
            {
                message = "Insurance Expiry Date is nearing Start the process of Renewing the Insurance";
            }
            else
            {
                message = "No action needed regarding Vehicle Insurance";
            }
            return message;
        }
    }
}
