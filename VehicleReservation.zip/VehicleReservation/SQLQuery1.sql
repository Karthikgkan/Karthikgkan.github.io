create database Vehicle_Reservation

create table User_Info
(Employee_Id varchar(6),
First_Name varchar(50),
Last_Name varchar(50),
Age int,
Gender varchar(10),
Contact_Number varchar(10),
Email_ID varchar(50),
Pass_word varchar(15),
Branch varchar(5)
);

--insert into Vehicle_Info(Vehicle_No,Branch,Vehicle_type,Insurance_Expiry_date,Last_Serviced_Date,Service_Due_date)values('761114','chennai','bike','2021/09/24','2019/03/11','2019/12/31')
--insert into Vehicle_Info(Vehicle_No,Branch,Vehicle_type,Insurance_Expiry_date,Last_Serviced_Date,Service_Due_date)values('765674','coimbatore','care','2023/09/04','2020/09/21','2020/12/31')

--drop table User_Info

create table Vehicle_Info
(Vehicle_No varchar(50),
Branch varchar(50),
Vehicle_type varchar(50),
Insurance_Expiry_date date,
Last_Serviced_Date date,
Service_Due_date date
);

--drop table Vehicle_Info

create proc search
@Vehicle_No varchar(50)
as
begin
select* from Vehicle_Info where Vehicle_No=@Vehicle_No;
end


--search '765674'

--drop proc search

--select * from Vehicle_Info


