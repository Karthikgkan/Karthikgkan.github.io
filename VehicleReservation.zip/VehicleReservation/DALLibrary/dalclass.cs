﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DALLibrary
{
    public class dalclass
    {
        public void Admin_Info(string _employeeidad, string _fnamead, string _lnamead, int _agead, string _genderad, string _contactnoad, string _emailad, string _passwordad, string _securityqnad, string _securityansad, string _branchad)
        {

            SqlConnection con5 = new SqlConnection("Data Source = PC430776; database = Vehicle_Reservation; uid =sql; password =password-2");
            con5.Close();
            con5.Open();
            SqlCommand com5 = new SqlCommand();
            com5.Connection = con5;
            com5.CommandType = CommandType.StoredProcedure;
            com5.CommandText = "insert_admin";
            com5.Parameters.AddWithValue("@employeeidad", _employeeidad);
            com5.Parameters.AddWithValue("@fnamead", _fnamead);
            com5.Parameters.AddWithValue("@lnamead", _lnamead);
            com5.Parameters.AddWithValue("@agead", _agead);
            com5.Parameters.AddWithValue("@genderad", _genderad);
            com5.Parameters.AddWithValue("@contactnoad", _contactnoad);
            com5.Parameters.AddWithValue("@emailad", _emailad);
            com5.Parameters.AddWithValue("@passwordad", _passwordad);
            com5.Parameters.AddWithValue("@securityqnad", _securityqnad);
            com5.Parameters.AddWithValue("@securityansad", _securityansad);
            com5.Parameters.AddWithValue("@branchad", _branchad);
            com5.ExecuteNonQuery();
            con5.Close();

        }
        public void User_Info(string _employeeid, string _fname, string _lname, int _age, string _gender, string _contactno, string _email, string _password,string _securityqn,string _securityans,string _branch)
        {
           
            SqlConnection con1 = new SqlConnection("Data Source = PC430776; database = Vehicle_Reservation; uid =sql; password =password-2");
            con1.Close();
            con1.Open();
            SqlCommand com1 = new SqlCommand();
            com1.Connection = con1;
            com1.CommandType = CommandType.StoredProcedure;
            com1.CommandText ="insert_user";
            com1.Parameters.AddWithValue("@employeeid",_employeeid);
            com1.Parameters.AddWithValue("@fname", _fname);
            com1.Parameters.AddWithValue("@lname", _lname);
            com1.Parameters.AddWithValue("@age",_age);
            com1.Parameters.AddWithValue("@gender", _gender);
            com1.Parameters.AddWithValue("@contactno", _contactno);
            com1.Parameters.AddWithValue("@email",_email);
            com1.Parameters.AddWithValue("@password", _password);
            com1.Parameters.AddWithValue("@securityqn",_securityqn);
            com1.Parameters.AddWithValue("@securityans",_securityans);
            com1.Parameters.AddWithValue("@branch", _branch);
            com1.ExecuteNonQuery();
            con1.Close();
            
        }

        public int LoginDAL(string _employeeid, string _password)
        {
            SqlConnection con2 = new SqlConnection("Data Source = PC430776; database = Vehicle_Reservation; uid =sql; password =password-2");
            con2.Close();
            con2.Open();
            SqlCommand com2 = new SqlCommand();
            com2.Connection = con2;
            com2.CommandType = CommandType.StoredProcedure;
            com2.CommandText = "Login";
            com2.Parameters.AddWithValue("@employeeid",_employeeid);
            com2.Parameters.AddWithValue("@password",_password);
            int a = (int)com2.ExecuteScalar();
            return a;
        }

        public int LoginadDAL(string _employeeidad, string _passwordad)
        {
            SqlConnection con6 = new SqlConnection("Data Source = PC430776; database = Vehicle_Reservation; uid =sql; password =password-2");
            con6.Close();
            con6.Open();
            SqlCommand com6 = new SqlCommand();
            com6.Connection = con6;
            com6.CommandType = CommandType.StoredProcedure;
            com6.CommandText = "Loginad";
            com6.Parameters.AddWithValue("@employeeidad", _employeeidad);
            com6.Parameters.AddWithValue("@passwordad", _passwordad);
            int a = (int)com6.ExecuteScalar();
            return a;
        }

        public int SecurityDAL(string _employeeid,string _securityqn, string _securityans)
        {
            SqlConnection con4 = new SqlConnection("Data Source = PC430776; database = Vehicle_Reservation; uid = sql; password = password-2");
            con4.Close();
            con4.Open();
            SqlCommand com4 = new SqlCommand();
            com4.Connection = con4;
            com4.CommandType = CommandType.StoredProcedure;
            com4.CommandText = "Security";
            com4.Parameters.AddWithValue("@employeeid",_employeeid);
            com4.Parameters.AddWithValue("@securityqn",_securityqn);
            com4.Parameters.AddWithValue("@securityans",_securityans);
            int a = (int)com4.ExecuteScalar();
            return a;
        }

        public int SecurityadDAL(string _employeeidad, string _securityqnad, string _securityansad)
        {
            SqlConnection con7 = new SqlConnection("Data Source = PC430776; database = Vehicle_Reservation; uid = sql; password = password-2");
            con7.Close();
            con7.Open();
            SqlCommand com7 = new SqlCommand();
            com7.Connection = con7;
            com7.CommandType = CommandType.StoredProcedure;
            com7.CommandText = "Securityad";
            com7.Parameters.AddWithValue("@employeeidad", _employeeidad);
            com7.Parameters.AddWithValue("@securityqnad", _securityqnad);
            com7.Parameters.AddWithValue("@securityansad", _securityansad);
            int a = (int)com7.ExecuteScalar();
            return a;
        }
        public void ForgotDAL(string _employeeid, string _password)
        {
            SqlConnection con3 = new SqlConnection("Data Source = PC430776; database = Vehicle_Reservation; uid =sql; password =password-2");
            con3.Close();
            con3.Open();
            SqlCommand com3 = new SqlCommand();
            com3.Connection = con3;
            com3.CommandType = CommandType.StoredProcedure;
            com3.CommandText = "forgotpassword";
            com3.Parameters.AddWithValue("@employeeid",_employeeid);
            com3.Parameters.AddWithValue("@password",_password);
            com3.ExecuteNonQuery();
        }

        public void ForgotadDAL(string _employeeidad, string _passwordad)
        {
            SqlConnection con8 = new SqlConnection("Data Source = PC430776; database = Vehicle_Reservation; uid =sql; password =password-2");
            con8.Close();
            con8.Open();
            SqlCommand com8 = new SqlCommand();
            com8.Connection = con8;
            com8.CommandType = CommandType.StoredProcedure;
            com8.CommandText = "forgotpasswordad";
            com8.Parameters.AddWithValue("@employeeidad", _employeeidad);
            com8.Parameters.AddWithValue("@passwordad", _passwordad);
            com8.ExecuteNonQuery();
        }



        public DataTable Search(string vehicle_no)
        {
            string search = "select * from Vehicle_Info where Vehicle_No=@Vehicle_No";
            SqlConnection con = new SqlConnection("Data Source=PC430776;database=Vehicle_Reservation;uid=sql;password=password-2");
            con.Open();
            SqlCommand com = new SqlCommand(search, con);
            com.Parameters.AddWithValue("@Vehicle_No", vehicle_no);
            SqlDataAdapter sqldata = new SqlDataAdapter("search",con);
            SqlDataReader dr = com.ExecuteReader();
           DataTable dtbl = new DataTable();
            dtbl.Load(dr);
            return dtbl;
            
        }
        public DateTime InsuranceExpiry(string vehicle_no)
        {
            SqlConnection con9 = new SqlConnection("Data Source=PC430776;database=Vehicle_Reservation;uid=sql;password=password-2");
            con9.Close();
            con9.Open();
            SqlCommand com9 = new SqlCommand();
            com9.Connection = con9;
            com9.CommandType = CommandType.StoredProcedure;
            com9.CommandText = "ExpiryDate";
            com9.Parameters.AddWithValue("@Vehicle_No", vehicle_no);
            DateTime a=(DateTime)com9.ExecuteScalar();
            return a;
        }

    }
}
