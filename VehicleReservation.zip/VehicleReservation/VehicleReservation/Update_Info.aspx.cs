﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;

namespace VehicleReservation
{
    public partial class UpdateInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void lbInsert_Click(object sender, EventArgs e)
        {
            SqlDataSource1.InsertParameters["Vehicle_No"].DefaultValue =
                ((TextBox)GridView1.FooterRow.FindControl("txtVehicleNo")).Text;
            SqlDataSource1.InsertParameters["Vehicle_Type"].DefaultValue =
                ((TextBox)GridView1.FooterRow.FindControl("txtVehicleType")).Text;
            SqlDataSource1.InsertParameters["Branch"].DefaultValue =
                ((TextBox)GridView1.FooterRow.FindControl("txtBranch")).Text;
            SqlDataSource1.InsertParameters["Insurance_type"].DefaultValue =
                ((DropDownList)GridView1.FooterRow.FindControl("ddlInsuranceType")).SelectedValue;
            SqlDataSource1.InsertParameters["Insurance_Expiry_Date"].DefaultValue =
                ((TextBox)GridView1.FooterRow.FindControl("txtInsuranceExpiryDate")).Text;
            SqlDataSource1.InsertParameters["last_Serviced_Date"].DefaultValue =
                ((TextBox)GridView1.FooterRow.FindControl("txtLastServicedDate")).Text;
            SqlDataSource1.InsertParameters["Service_due_date"].DefaultValue =
                ((TextBox)GridView1.FooterRow.FindControl("txtServiceDueDate")).Text;
            SqlDataSource1.Insert();
        }

        //protected void btnnotify_Click(object sender, EventArgs e)
        //{
        //    string Message = "Email Message";
        //    DateTime a = DateTime.Parse(((TextBox)GridView1.FooterRow.FindControl("txtVehicleNo")).Text);
        //    DateTime now = DateTime.Now;
        //    TimeSpan diff = now - a;
        //    int b = int.Parse(diff.ToString());
        //    if (b <= 15)
        //    {
        //        string sendEmail = ConfigurationManager.AppSettings["SendEmail"];
        //        if (sendEmail.ToLower() == "true")
        //        {
        //            SendEmail(Message);
        //        }
        //    }
        //}
        //    protected void SendEmail(string emailBody)
        //    {
        //        MailMessage mailMessage = new MailMessage("SeemaPriyaDharshini.S@cognizant.com", "SeemaPriyaDharshini.S@cognizant.com");
        //        mailMessage.Subject = "Notification";
        //        mailMessage.Body = emailBody;

        //        SmtpClient smtpClient = new SmtpClient("smtp-mail.outlook.com", 587);
        //        smtpClient.Credentials = new System.Net.NetworkCredential()
        //        {
        //            UserName = "SeemaPriyaDharshini.S@cognizant.com",
        //            Password = "___________"
        //        };
        //        smtpClient.EnableSsl = true;
        //        smtpClient.Send(mailMessage);

        //    }
        }
    }
