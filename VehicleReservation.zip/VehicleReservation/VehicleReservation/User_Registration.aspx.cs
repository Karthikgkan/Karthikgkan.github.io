﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLLibrary;

namespace VehicleReservation
{
    public partial class UserRegForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnregister_Click(object sender, EventArgs e)
        {
            bllclass bc = new bllclass();
            bc.Insert_UserBL(txtemployeeid.Text, txtfname.Text, txtlname.Text, int.Parse(txtage.Text), dpdlgender.SelectedItem.Text, txtphone.Text, txtemailid.Text, txtpassword.Text, dpdlsecurity1.Text, txtsecurity.Text, txtbranch.Text);
            lblreg.Text = "Registration Successful";
        }
    }
}