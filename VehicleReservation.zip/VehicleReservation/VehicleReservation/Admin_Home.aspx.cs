﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLLibrary;
using System.Data;
using System.Data.SqlClient;

namespace VehicleReservation
{
    public partial class AdminForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=PC430776;database=Vehicle_Reservation;uid=sql;password=password-2");
            SqlCommand com = new SqlCommand();
            com.Connection = con;

            lblalert.Text = "";
        }
    }
}