﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLLibrary;

namespace VehicleReservation
{
    public partial class Forgot_Password2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblemployeesend.Text = Request.QueryString["Name"];
        }

        protected void btnsecurity_Click(object sender, EventArgs e)
        {
            bllclass bc = new bllclass();
            bc.ForgotBAL(lblemployeesend.Text, txtnewpassword.Text);
            lblforgot.Text = "Password Reset Successful";
            
        }
    }
}