﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLLibrary;

namespace VehicleReservation
{
    public partial class AdminRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnregisterad_Click(object sender, EventArgs e)
        {
            bllclass bc = new bllclass();
            bc.Insert_AdminBL(txtemployeeidad.Text, txtfnamead.Text, txtlnamead.Text, int.Parse(txtagead.Text), dpdlgenderad.SelectedItem.Text, txtphonead.Text, txtemailidad.Text, txtpasswordad.Text, dpdlsecurityad.Text, txtsecurityad.Text, txtbranchad.Text);
            lblregad.Text = "Registration Successful";
        }
    }
}