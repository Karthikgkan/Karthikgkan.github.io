﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLLibrary;
using System.Data;
using System.Configuration;
using System.Net.Mail;

namespace VehicleReservation
{
    public partial class SearchInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void imgbtnsearch_Click(object sender, ImageClickEventArgs e)
        {
            bllclass bc = new bllclass();
            DataTable d = bc.SearchBL(txtsearch.Text);
            gvsearch.DataSource = d;
            gvsearch.DataBind();
        }

        protected void btnexpiry_Click(object sender, EventArgs e)
        {
            
            bllclass bc = new bllclass();
            string a = bc.ExpiryDate(txtsearch.Text);
            lblexpiry.Text = a;
        }
        public static void SendEmail(string emailBody)
        {
            MailMessage mailMessage = new MailMessage("skarthik2997@gmail.com", "skarthik2997@gmail.com");
            mailMessage.Subject = "Notification";
            mailMessage.Body = emailBody;

            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);
            smtpClient.Credentials = new System.Net.NetworkCredential()
            {
                UserName = "skarthik2997@gmail.com",
                Password = "----------------------"
            };
            smtpClient.EnableSsl = true;
            smtpClient.Send(mailMessage);

        }

        protected void btnmail_Click(object sender, EventArgs e)
        {
            bllclass bc = new bllclass();
            string a = bc.ExpiryDate(txtsearch.Text);
            string sendEmail = ConfigurationManager.AppSettings["SendEmail"];
            if (sendEmail.ToLower() == "true")
            {
                SendEmail(a);
            }
        }
    }
}