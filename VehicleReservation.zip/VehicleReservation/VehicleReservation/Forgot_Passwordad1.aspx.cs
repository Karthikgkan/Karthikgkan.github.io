﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLLibrary;

namespace VehicleReservation
{
    public partial class Forgot_Passwordad1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            bllclass bc = new bllclass();
            int a = bc.SecurityadBAL(txtemployeeidad.Text, dpdlsecurityad.SelectedItem.Text, txtsecurityad.Text);
            if (a != 0)
            {
                //Response.Redirect("Forgot_Password2.aspx");
                Response.Redirect("Forgot_Passwordad2.aspx?Name=" + txtemployeeidad.Text);
            }
            else
            {
                lblsecurityfailad.Text = "Security answer is wrong...Please Try again";
            }
        }
    }
}