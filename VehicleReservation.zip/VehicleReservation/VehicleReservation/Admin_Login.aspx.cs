﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLLibrary;
namespace VehicleReservation
{
    public partial class Admin_Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            bllclass bc = new bllclass();
            int a = bc.LoginadBAL(txtemployeeidad.Text, txtpasswordad.Text);
            if (a != 0)
            {
                Response.Redirect("Admin_Home.aspx");
            }
            else
            {
                lblloginerrorad.Text = "Login Unsuccessful";
            }
        }
    }
}