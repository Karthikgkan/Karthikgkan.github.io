﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLLibrary;

namespace VehicleReservation
{
    public partial class Forgot_Password : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            bllclass bc = new bllclass();
            int a = bc.SecurityBAL(txtemployeeid.Text,dpdlsecurity.SelectedItem.Text,txtsecurity.Text);
            if (a != 0)
            {
                //Response.Redirect("Forgot_Password2.aspx");
                Response.Redirect("Forgot_Password2.aspx?Name=" +txtemployeeid.Text);
            }
            else
            {
                lblsecurityfail.Text = "Security answer is wrong...Please Try again";
            }
            
        }
    }
}